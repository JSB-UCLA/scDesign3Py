class ConvertionError(RuntimeError):
    pass


class InputError(RuntimeError):
    pass


class SequentialError(RuntimeError):
    pass

class NotInplementedError(RuntimeError):
    pass
