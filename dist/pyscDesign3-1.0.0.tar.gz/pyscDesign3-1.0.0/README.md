# **pyscDesign3**: python interface for **scDesign3** **R** package

For detailed tutorial of this package, please visit the document [website](https://diliu899.github.io/pyscDesign3/).
